﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Abp;
using Abp.Dependency;
using Castle.Facilities.Logging;
using KPCS.Web.Models.TokenAuth;
using Newtonsoft.Json;
using RestSharp;

namespace AbpEfConsoleApp
{
    public class Program
    {
        static async System.Threading.Tasks.Task Main(string[] args)
        {
            //Bootstrapping ABP system
            using (var bootstrapper = AbpBootstrapper.Create<MyConsoleAppModule>())
            {
                bootstrapper.IocManager
                    .IocContainer
                    .AddFacility<LoggingFacility>(f => f.UseLog4Net().WithConfig("log4net.config"));

                bootstrapper.Initialize();

                //Getting a Tester object from DI and running it
                using (var tester = bootstrapper.IocManager.ResolveAsDisposable<Tester>())
                {
                    tester.Object.Run();
                } //Disposes tester and all it's dependencies

               using (var client = new HttpClient())
                {
                    var accessToken = "";
                    var accessTokenStr = "";
                    var requesttoken = new HttpRequestMessage()
                    {
                        RequestUri = new Uri("https://localhost:44352/api/TokenAuth/Authenticate"),
                        Method = HttpMethod.Post,
                    };
                    //requesttoken.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/plain"));
                    requesttoken.Headers.Add("Abp.TenantId", "3");
                    //requesttoken.Headers.Add("Accept", "*/*");
                    //requesttoken.Headers.Add("Content-Type", "application/json");
                    var byteArray = Encoding.ASCII.GetBytes($"admin:123qwe");
                    //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                    requesttoken.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(byteArray));
                    AuthenticateModel input = new AuthenticateModel();
                    input.UserNameOrEmailAddress = "admin";
                    input.Password = "123qwe";
                    var json = JsonConvert.SerializeObject(input);
                    //var json = JsonConvert.SerializeObject("{\"userNameOrEmailAddress\":\"admin\",\"password\":\"123qwe\"}");
                    var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
                    stringContent.Headers.ContentType.CharSet = string.Empty;
                    requesttoken.Content = stringContent;

                    var tasktoken = client.SendAsync(requesttoken)
                    .ContinueWith((taskwithmsg) =>
                    {
                        HttpResponseMessage response = taskwithmsg.Result;

                        var jsonTask = response.Content.ReadAsStringAsync();
                        //var jsonTask = response.Content.ReadAsAsync<JsonObject>();
                        jsonTask.Wait();
                        
                        accessToken = jsonTask.Result;
                        Result res = JsonConvert.DeserializeObject<Result>(accessToken);
                        //AuthenticateResultModel accessTokenObj = (AuthenticateResultModel)JsonConvert.DeserializeObject(accessToken);
                        AuthenticateResultModel accessTokenObj = res.result;
                         accessTokenStr = accessTokenObj.AccessToken;
                        Console.WriteLine(accessTokenStr);
                    });
                    tasktoken.Wait();
                    ///////////////////////////

                    //var accessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjQiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiYWRtaW4iLCJBc3BOZXQuSWRlbnRpdHkuU2VjdXJpdHlTdGFtcCI6IklCMlJBNEVSRVhHWVpWRTI2VFk3VTNLWEtCWlVOSkJQIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiQWRtaW4iLCJodHRwOi8vd3d3LmFzcG5ldGJvaWxlcnBsYXRlLmNvbS9pZGVudGl0eS9jbGFpbXMvdGVuYW50SWQiOiIzIiwic3ViIjoiNCIsImp0aSI6IjA2NTU1N2U1LTkwNjgtNGNhYS1iNjVlLWZlNjc2Y2M3ZDM1ZCIsImlhdCI6MTYwNzA4MTI5MywidG9rZW5fdmFsaWRpdHlfa2V5IjoiY2Q3MWQzNzEtMGQ1MS00NDcyLThjMzktMWQyNTc0OTJiNTc3IiwidXNlcl9pZGVudGlmaWVyIjoiNEAzIiwidG9rZW5fdHlwZSI6IjAiLCJuYmYiOjE2MDcwODEyOTMsImV4cCI6MTYwNzE2NzY5MywiaXNzIjoiS1BDUyIsImF1ZCI6IktQQ1MifQ.lZ6tiHs6G8G_M0IQRfVMDzS6K1xQGd9vMi5cKgQdLnc";
                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri("https://localhost:44352/api/services/app/User/GetUsers"),
                    Method = HttpMethod.Get,
                };
                //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/plain"));
                //request.Headers.Add("Content-Type", "application/json");
                request.Headers.Add("Abp.TenantId", "3");
                request.Headers.Add("Authorization", "Bearer "+ accessTokenStr);
                    var task = client.SendAsync(request)
                    .ContinueWith((taskwithmsg) =>
                    {
                        HttpResponseMessage response = taskwithmsg.Result;

                        var jsonTask = response.Content.ReadAsStringAsync();
                        jsonTask.Wait();
                        var jsonObject = jsonTask.Result;
                        Console.WriteLine(jsonObject);
                    });
                    task.Wait();

                    /* if (response.IsSuccessStatusCode)
                 {
                     Console.WriteLine("Data got");                        
                 }
                 else
                 {
                     Console.WriteLine($"Failed to get data. Status code:{response.StatusCode}");
                 }*/
                }

                /*var client = new HttpClient();
                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri("https://localhost:44352/api/services/app/User/GetUsers"),
                    Method = HttpMethod.Get,
                };
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/plain"));
                request.Headers.Add("Content-Type", "application/json");
                request.Headers.Add("Abp.TenantId", "3");
                request.Headers.Add("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjQiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiYWRtaW4iLCJBc3BOZXQuSWRlbnRpdHkuU2VjdXJpdHlTdGFtcCI6IklCMlJBNEVSRVhHWVpWRTI2VFk3VTNLWEtCWlVOSkJQIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiQWRtaW4iLCJodHRwOi8vd3d3LmFzcG5ldGJvaWxlcnBsYXRlLmNvbS9pZGVudGl0eS9jbGFpbXMvdGVuYW50SWQiOiIzIiwic3ViIjoiNCIsImp0aSI6IjA2NTU1N2U1LTkwNjgtNGNhYS1iNjVlLWZlNjc2Y2M3ZDM1ZCIsImlhdCI6MTYwNzA4MTI5MywidG9rZW5fdmFsaWRpdHlfa2V5IjoiY2Q3MWQzNzEtMGQ1MS00NDcyLThjMzktMWQyNTc0OTJiNTc3IiwidXNlcl9pZGVudGlmaWVyIjoiNEAzIiwidG9rZW5fdHlwZSI6IjAiLCJuYmYiOjE2MDcwODEyOTMsImV4cCI6MTYwNzE2NzY5MywiaXNzIjoiS1BDUyIsImF1ZCI6IktQQ1MifQ.lZ6tiHs6G8G_M0IQRfVMDzS6K1xQGd9vMi5cKgQdLnc");
                var task = client.SendAsync(request)
                    .ContinueWith((taskwithmsg) =>
                    {
                        var response = taskwithmsg.Result;

                        var jsonTask = response.Content.ReadAsAsync<JsonObject>();
                        jsonTask.Wait();
                        var jsonObject = jsonTask.Result;
                    });
                task.Wait();*/

                Console.WriteLine("Press enter to exit...");
                Console.ReadLine();
            }
        }
    }
}
