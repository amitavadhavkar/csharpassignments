using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using KPCS.CommunicationReceiver.Shared;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace KPCS.Receiver.Application
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public IServiceProvider Services { get; }
        public Worker(ILogger<Worker> logger, IServiceProvider services)
        {
            _logger = logger;
            Services = services;
        }

        public virtual void Dispose()
        {
            _logger.LogInformation("Worker Disposing");
        }
        
        //If below is used, ExecuteAsync is not reached. So keep commented. we want control on stop and we are getting that by StopAsync()
        //We can stop ActiveMQ listeners in StopAsync()
        /*public override Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Worker Started");
            return Task.CompletedTask;
        }*/
        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Worker Stopped");
            return Task.CompletedTask;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await DoWork(stoppingToken);

            //while (!stoppingToken.IsCancellationRequested)
            //{
            //    _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);

            //    //await Task.Delay(1000, stoppingToken);
            //}
        }
        private async Task DoWork(CancellationToken stoppingToken)
        {
            _logger.LogInformation(
                "Consume MessageListenerService Service is working.");

            using (var scope = Services.CreateScope())
            {
                var messageListenerService =
                    scope.ServiceProvider
                        .GetRequiredService<IMessageListenerService>();

                 messageListenerService.RunAsync();
            }
        }
    }
}
