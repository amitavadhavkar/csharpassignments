using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KPCS.CommunicationReceiver.Service;
using KPCS.CommunicationReceiver.Shared;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.EventLog;
using Microsoft.Extensions.Hosting.WindowsServices;
using Serilog.Enrichers;
using Serilog.Extensions.Hosting;
using Serilog.Sinks.SystemConsole;
using Serilog.Sinks.File;
using Serilog.Sinks.EventLog;
using System.IO;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.SystemConsole.Themes;

//https://codeburst.io/create-a-windows-service-app-in-net-core-3-0-5ecb29fb5ad0
//https://csharp.christiannagel.com/2019/10/15/windowsservice/

namespace KPCS.Receiver.Application
{
    public class Program
    {
        public static void Main(string[] args)
        {
            const string loggerTemplate = @"{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u4}]<{ThreadId}> [{SourceContext:l}] {Message:lj}{NewLine}{Exception}";
            var baseDir = AppDomain.CurrentDomain.BaseDirectory;
            var logfile = Path.Combine(baseDir, "RcvrApp_Data", "logs", "log.txt");
            Console.WriteLine(logfile);
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .Enrich.With(new ThreadIdEnricher())
                .Enrich.FromLogContext()
                .WriteTo.Console(LogEventLevel.Information, loggerTemplate, theme: AnsiConsoleTheme.Literate)
                .WriteTo.File(logfile, LogEventLevel.Information, loggerTemplate,
                    rollingInterval: RollingInterval.Day, retainedFileCountLimit: 90)
                .WriteTo.EventLog("Rcvr Sample App", manageEventSource: true)
                .CreateLogger();

            try
            {
                Log.Information("====================================================================");
                Log.Information($"Application Starts. Version: {System.Reflection.Assembly.GetEntryAssembly()?.GetName().Version}");
                Log.Information($"Application Directory: {AppDomain.CurrentDomain.BaseDirectory}");
                Log.Information("log file:" + logfile);
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception e)
            {
                Log.Fatal(e, "Application terminated unexpectedly");
            }
            finally
            {
                Log.Information("====================================================================\r\n");
                Log.CloseAndFlush();
            }
            CreateHostBuilder(args).Build().Run();
        }
  
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            //IocManager
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddHostedService<Worker>().Configure<EventLogSettings>(config =>
                    {
                        config.LogName = "Sample Service";
                        config.SourceName = "Sample Service Source";
                    });
                    //services.AddHostedService<MessageListenerService>();
                    services.AddScoped<IMessageListenerService, MessageListenerService>();

                })
            .ConfigureLogging(
                options => options.AddFilter<EventLogLoggerProvider>(level => level >= LogLevel.Information))
            .UseWindowsService()
            .UseSerilog();
        //.ConfigureLogging((hostContext, configLogging) =>
        //{
        //    configLogging.AddEventLog();
        //    configLogging.AddConsole();
        //    configLogging.AddDebug();
        //});


    }
}
