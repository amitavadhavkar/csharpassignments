﻿using Abp.Application.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace KPCS.Receiver.Application
{
    public abstract class KPCSReceiverApplicationBase: ApplicationService
    {
    }
}
