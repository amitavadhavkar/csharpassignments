﻿using System.Data.Entity;
using Abp.EntityFramework;
using KPCS.PersonDetails;
using Microsoft.EntityFrameworkCore;

namespace AbpEfConsoleApp
{
    //EF DbContext class.
    public class MyConsoleAppDbContext : AbpDbContext
    {
        public virtual IDbSet<User> Users { get; set; }
        public virtual IDbSet<Address> Addresses { get; set; }
        public virtual IDbSet<Country> Countries { get; set; }
        public virtual IDbSet<StateOrProvince> StateOrProvince { get; set; }


        public MyConsoleAppDbContext()
            : base("Default")
        {

        }

        public MyConsoleAppDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {

        }
    }
}