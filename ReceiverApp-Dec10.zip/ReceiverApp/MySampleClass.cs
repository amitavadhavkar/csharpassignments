﻿using Abp.Dependency;
using KPCS.PersonDetails;
using System;
using System.Collections.Generic;
using System.Text;

namespace ReceiverApp
{
    public class MySampleClass : ITransientDependency
    {
        private readonly IIocResolver _iocResolver;

        public MySampleClass(IIocResolver iocResolver)
        {
            _iocResolver = iocResolver;
        }

        public async System.Threading.Tasks.Task DoItAsync()
        {
            //Resolving, using and releasing manually
            /*var personService1 = _iocResolver.Resolve<PersonAppService>();
            personService1.CreatePerson(new CreatePersonInput { Name = "John", Surname = "Doe" });
            _iocResolver.Release(personService1);

            //Resolving and using in a safe way
            using (var personService2 = _iocResolver.ResolveAsDisposable<PersonAppService>())
            {
                personService2.Object.CreatePerson(new CreatePersonInput { Name = "John", Surname = "Doe" });
            }*/

            using (var scope = _iocResolver.CreateScope())
            {
                var simpleObj1 = scope.Resolve<HelloWorldService>();
                simpleObj1.SayHello();
                //...
            }

            using (var scope = _iocResolver.CreateScope())
            {
                var simpleObj1 = scope.Resolve<AddressesAppService>();
                await simpleObj1.GetAllCountryForTableDropdown();
                //...
            }
        }
    }
}
