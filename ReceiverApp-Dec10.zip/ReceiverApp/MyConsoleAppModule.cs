using System;
using System.IO;
using System.Reflection;
using Abp.Dependency;
using Abp.Domain.Repositories;
using Abp.EntityFramework;
using Abp.EntityFrameworkCore.Configuration;
using Abp.Modules;
using KPCS.Authorization.Users;
using KPCS.PersonDetails;
using KPCS.PersonDetails.Exporting;
using KPCS.Storage;
using Microsoft.Extensions.Configuration;
using ReceiverApp;

namespace AbpEfConsoleApp
{
    [DependsOn(typeof(AbpEntityFrameworkModule))]
    public class MyConsoleAppModule : AbpModule
    {
        public static string dbChoice = Console.ReadLine();
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
            IocManager.Register<IUserAppService, UserAppService>(DependencyLifeStyle.Transient);
            IocManager.Register<IAddressesAppService, AddressesAppService>(DependencyLifeStyle.Transient);
            IocManager.Register<IRepository<Address, long>>(DependencyLifeStyle.Transient);
            IocManager.Register<IRepository<Country, long>>(DependencyLifeStyle.Transient);
            IocManager.Register<IRepository<StateOrProvince, long>>(DependencyLifeStyle.Transient);
            IocManager.Register<IAddressesExcelExporter, AddressesExcelExporter>(DependencyLifeStyle.Transient);
            IocManager.Register<ITempFileCacheManager, TempFileCacheManager>(DependencyLifeStyle.Transient);
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
            //private readonly IRepository<Address, long> _addressRepository;
            // private readonly IAddressesExcelExporter _addressesExcelExporter;
            //private readonly IRepository<Country, long> _lookup_countryRepository;
            //private readonly IRepository<StateOrProvince, long> _lookup_stateOrProvinceRepository;

            //IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
            //IocManager.Register<IHelloWorldService, HelloWorldService>(DependencyLifeStyle.Transient);
            /*Configuration.Modules.AbpEfCore().AddDbContext<MyConsoleAppDbContext>(options =>
            {
                options.DbContextOptions.UseSqlServer(options.ConnectionString);
            });*/
            // IocManager.IocContainer.Resolve("userService", IUserAppService);
            //var userAppService = IocManager.IocContainer.Resolve<IUserAppService>();
            //userAppService.GetUsers();

            //HelloWorldService helloWorldService = (HelloWorldService)IocManager.IocContainer.Resolve<IHelloWorldService>();
            //helloWorldService.SayHello();
        }

        public override void PreInitialize()
        {
            //Configuration.DefaultNameOrConnectionString = GetConnectionString("Default");
            //Console.WriteLine(Configuration.Get("ConnectionStrings"));

            var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", false)
               //.AddJsonFile($"appsettings.{environmentName}.json", true)
               .AddEnvironmentVariables();

            IConfigurationRoot configuration = builder.Build();
            string dbconstr = "";
            //dbChoice = Console.ReadLine(); //TODO need to enter twice
            dbChoice = "Default";
            if (dbChoice.Equals("Default"))
            {
                dbconstr = configuration.GetConnectionString("Default");
            }
            else if(dbChoice.Equals("TestDB"))
            {
                dbconstr = configuration.GetConnectionString("TestDB");
            }
            Console.WriteLine(dbconstr);

            Configuration.DefaultNameOrConnectionString = dbconstr;
        }

        /*private string GetConnectionString(string dbcon)
        {
            return "Data Source=.\\sqlexpress;Initial Catalog=TestDB;Integrated Security=True;Max Pool Size= 150";
        }*/

       
    }
}