﻿using Abp.Application.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace ReceiverApp
{
    public interface IHelloWorldService : IApplicationService
    {
    }
}
