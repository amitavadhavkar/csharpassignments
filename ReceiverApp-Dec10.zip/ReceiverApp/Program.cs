﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Abp;
using Abp.Castle.Logging.Log4Net;
using Abp.Dependency;
using AbpEfConsoleApp;
using Castle.Facilities.Logging;
using KPCS.Authorization.Users;
using KPCS.PersonDetails;
using KPCS.PersonDetails.Dtos;
using Microsoft.Extensions.Configuration;
using System.Linq;
//https://stackoverflow.com/questions/38114761/asp-net-core-configuration-for-net-core-console-application
//https://docs.abp.io/en/abp/1.1/Getting-Started-Console-Application
//https://stackoverflow.com/questions/42927161/registering-new-dependency
/*
 * The source IQueryable doesn't implement IAsyncEnumerable<KPCS.PersonDetails.Dtos.AddressCountryLookupTableDto>. Only sources that implement IAsyncEnumerable can be used for Entity Framework asynchronous operations
 * */
namespace ReceiverApp
{
    class Program
    {
        static async Task Main(string[] args)
        //static void Main(string[] args)
        {
            //Bootstrapping ABP system
            using (var bootstrapper = AbpBootstrapper.Create<MyConsoleAppModule>())
            {
                bootstrapper.IocManager
                    .IocContainer
                    .AddFacility<LoggingFacility>(f => f.UseAbpLog4Net().WithConfig("log4net.config"));

                bootstrapper.Initialize();

                //Getting a Tester object from DI and running it
                if (MyConsoleAppModule.dbChoice.Equals("TestDB"))
                {
                    using (var tester = bootstrapper.IocManager.ResolveAsDisposable<Tester>())
                    {
                        tester.Object.Run();
                    } //Disposes tester and all it's dependencies
                }

                Test_Way_2(bootstrapper.IocManager);

                if (MyConsoleAppModule.dbChoice.Equals("Default"))
                {
                    await Test_Way_KPCLAsync(bootstrapper.IocManager);
                    //var result = await Test_Way_KPCLAsync(bootstrapper.IocManager);
                    /*if (result != null)
                    {
                        Console.WriteLine(result.ToList().Count);
                    }*/
                }

                //var tester1 = IocManager.Instance.Resolve<MySampleClass>();
                //Task task = tester1.DoItAsync();
                //task.Wait();
            }

            var environmentName = Environment.GetEnvironmentVariable("ENVIRONMENT");
            Console.WriteLine("ENVIRONMENT: " + environmentName);

            /*var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", false)
               .AddJsonFile($"appsettings.{environmentName}.json", true)
               .AddEnvironmentVariables();

            IConfigurationRoot configuration = builder.Build();
            Console.WriteLine(configuration.GetConnectionString("Default"));*/
            Console.WriteLine("Hello World!");

            //IUserAppService userAppService = ;
            //userAppService.GetUsers();

            
        }

        public static void Test_Way_2(IIocManager iocManager)
        {
            using (var helloWorldService = iocManager.ResolveAsDisposable<HelloWorldService>())
            {
                helloWorldService.Object.SayHello();
            }
        }

       // public static void Test_Way_KPCLAsync(IIocManager iocManager)
       public static async Task<List<AddressStateOrProvinceLookupTableDto>> Test_Way_KPCLAsync(IIocManager iocManager)
        {
            var addressesAppService = iocManager.Resolve<AddressesAppService>();
            
                //var result = addressesAppService.Object.GetAll();
                //Console.WriteLine(result.StateOrProvinceId);
                var result = await addressesAppService.GetAllStateOrProvinceForTableDropdown();
            return result;
            
            /*IQueryable resultQueryOut = result.AsQueryable();
            if (resultQueryOut != null)
            {
                Console.WriteLine("AM HERE");
            }
            else
            {
                Console.WriteLine("AM HERE - NULL");
            }*/
            //return await Task.FromResult(result.ToList());
            //return await Task.FromResult(result.Count);


        }
    }
}
