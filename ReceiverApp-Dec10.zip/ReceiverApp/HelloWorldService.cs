﻿using Abp.Dependency;
using System;
using System.Collections.Generic;
using System.Text;

namespace ReceiverApp
{
 
        public class HelloWorldService : IHelloWorldService
        {
            public void SayHello()
            {
                Console.WriteLine("Hello World Service!");
            }
        }

}
